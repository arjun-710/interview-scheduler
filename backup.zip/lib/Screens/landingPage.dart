import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:interview_scheduler/Components/MeetingCard.dart';
import 'package:interview_scheduler/models/Meeting.dart';
import 'package:interview_scheduler/services/meetingServices.dart';

class landingPage extends StatefulWidget {
  const landingPage({Key? key}) : super(key: key);

  @override
  State<landingPage> createState() => _landingPageState();
}

class _landingPageState extends State<landingPage> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return SingleChildScrollView(
      child: Column(
        children: [
          SizedBox(
            height: size.height,
            child: Stack(
              children: [
                Container(
                  margin: EdgeInsets.only(top: size.height * 0.4),
                  height: 500,
                  width: size.width,
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(25),
                      topRight: Radius.circular(25),
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(25.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        RichText(
                          text: const TextSpan(
                            text: "Your Meetings\n",
                            style: TextStyle(
                                color: Colors.black,
                                fontSize: 25,
                                fontFamily: 'segoe-UI'),
                          ),
                        ),
                        const SizedBox(height: 40),
                        Container(
                          child: StreamBuilder<List<Meeting>>(
                            stream: readMeetings(),
                            builder: (context, snapshot) {
                              if (snapshot.hasError) {
                                // print(snapshot);
                                return const Text("Something Went Wrong");
                              } else if (snapshot.hasData) {
                                final meetings = snapshot.data!;
                                // print(meetings);
                                return Container(
                                  height: size.height / 3,
                                  child: ListView(
                                    children:
                                        meetings.map(buildMeeting).toList(),
                                  ),
                                );
                              } else {
                                return const CircularProgressIndicator();
                              }
                            },
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
